### Hexlet tests and linter status:
[![Actions Status](https://github.com/NikLuki/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/NikLuki/python-project-49/actions)

## Установка:
Для установки используйте
pip install brain_games

## Запуск игры:
Для запуска ввести
make brain-games
Для игры brain-even:
make brain-even

## Пример игры brain-even:
https://asciinema.org/a/caOozKOiguC7CCKgWi21rTwdO

## Пример игры brain-calc:



## Победа или поражение:
Ответьте верно (yes/no) на три вопроса подряд, чтобы выиграть
При вводе неверного ответа, либо любых других символов - сообщение о проигрыше



